# Study Room Booking Tool — Project Documentation

## 1. Title and administrative metadata

| Item | Details |
|---|---|
| Project | Study Room Booking Tool |
| Course / task | ITPE3200 — Task 1 |
| Application type | Subapp 1 — ASP.NET Core 10 MVC |
| Version | 1.1 (simple student interface) |
| Database | SQLite with Entity Framework Core migrations |
| Documentation date | 28 October 2026 |
| Repository | `https://github.com/Hind-Ouf/study-room` (currently private) |
| Deployment | Local development only; no public cloud URL has been configured |

The tool helps students find free campus rooms and organize study sessions. A registered student can book a room, associate the session with one or more courses, and search sessions by subject, course, and time. Room and course catalogs are available to signed-in users.

## 2. Requirements analysis and traceability matrix

The assignment distinguishes the core task from inspiration features. Room search, booking, CRUD, a web form interface, and project documentation are core expectations. Participation features such as joining a session or leaving messages are optional inspirations and are not implemented in this version.

| Requirement | Implementation | Evidence / verification |
|---|---|---|
| ASP.NET 10 MVC web application | ASP.NET Core MVC, controllers, Razor views | `StudyRoomBooking.csproj`, `Controllers/`, `Views/` |
| Interactive web user interface | Responsive Bootstrap interface, search and CRUD forms | Home, Bookings, Rooms, Courses, and Account views |
| Application should not crash | Global exception and status-code handling; validation before persistence | `Program.cs`, controller error paths; build verification |
| CRUD for at least three domain entities | Room, Booking, Course | `RoomsController`, `BookingsController`, `CoursesController` |
| At least one many-to-many relationship | A booking can link to multiple courses, and a course can link to multiple bookings | `BookingCourse` join table configured in `ApplicationDbContext` |
| Complex server-side domain rule | Reject invalid or over-four-hour sessions; reject overlapping bookings for a room; disallow past starts | `Domain/BookingRules.cs`, `BookingService`, `BookingsController` |
| At least two types of conditional rendering | Empty results, empty catalog, projector badge, past-session styling, signed-in navigation | `Views/Home/Index.cshtml`, `Views/Bookings/Index.cshtml`, `Views/Shared/_Layout.cshtml` |
| Multi-parameter search and filtering | Room availability by time, floor, and projector; session filtering by subject, course, and time range | `HomeController`, `BookingsController`, `BookingRepository` |
| Repository Pattern and DAL | Repository contracts and EF Core SQLite implementations, used by services | `DAL/IRepository.cs`, `DAL/*Repository.cs`, `Services/` |
| Asynchronous database access | EF Core query and save methods use async APIs | `DAL/`, `Services/`, controllers |
| ViewModels for Subapp 1 | Separate booking, search, login, and registration view models | `ViewModels/` |
| Client/server validation, error handling, server logging | Data annotations, unobtrusive validation, server checks, safe form errors, `ILogger` | `ViewModels/`, `_ValidationScriptsPartial.cshtml`, controllers |
| Authentication and authorization | ASP.NET Core Identity registration/login; booking/catalog pages require a signed-in user; booking changes are owner-checked | `AccountController`, `[Authorize]`, `BookingsController` |
| 12 backend unit tests (6 positive, 6 negative) | Exactly 12 cases: six accepted scenarios and six rejected scenarios | `tests/StudyRoomBooking.Tests/BookingRulesTests.cs` |
| Documentation follows requested sections | This document contains sections 1–9 from the project template | `docs/PROJECT_DOCUMENTATION.md` |
| Examiner can access the solution | Run instructions and self-registration are provided below; repository is private and must be shared with examiners or made accessible | Section 6.4 and Section 9 |

## 3. System architecture and engineering decision records

### 3.1 Architecture

The application uses a conventional MVC structure:

```text
Browser
  └── MVC Controllers ── ViewModels ── Razor Views and small client scripts
          └── Application Services (booking rules and workflows)
                └── Repository interfaces and EF Core repositories
                      └── ApplicationDbContext ── SQLite
ASP.NET Core Identity ────────────────────────────┘
```

- **Controllers** handle HTTP requests, authorization, model validation, user messages, and logging.
- **ViewModels** define the fields and validation rules used by forms and search pages. Booking entities are not bound directly from the booking form.
- **Services** coordinate use cases and enforce booking rules.
- **Repositories** isolate EF Core queries and persistence from application services.
- **ApplicationDbContext** maps rooms, bookings, courses, Identity tables, and their relationships.
- **Razor Views** render the responsive user interface. Bootstrap and client-side validation scripts are delivered through a CDN, and a small JavaScript file loads selected room details on the booking form.

### 3.2 Main decisions

| Decision | Reason |
|---|---|
| ASP.NET Core MVC with Razor | This is the required platform for Subapp 1 and keeps forms and page rendering in one app. |
| SQLite and EF Core migrations | SQLite needs no separate database server. Migrations let the schema change without starting over. This app uses `studyrooms-v2.db` so it does not overwrite the earlier database. |
| Repositories and services | Repositories handle database queries. Services apply booking rules before saving. |
| ASP.NET Core Identity | Identity handles password storage and sign-in cookies. Students can create their own accounts; no shared password is needed. |
| Booking–Course many-to-many | A session can be linked to several courses. EF Core stores the links in `BookingCourse`. |
| Local run instructions | The app has not been deployed. `localhost` works only on the computer running it. |

### 3.3 Course material

The MVC, EF Core, and DAL layout follows the topics in the ITPE3200 examples. The app uses controllers, ViewModels, Razor views, repositories, services, async database calls, and migrations for its own room-booking features. The course sources used are listed in Section 7.3.

## 4. Database structure and access

### 4.1 Domain entities and relationships

| Entity / table | Purpose | Relationships |
|---|---|---|
| `Room` | Campus room name, floor, capacity, projector availability | One room has many bookings; room deletion cascades to its bookings |
| `Booking` | Room reservation and study-session subject, description, student number, time window, and owner | Many-to-one with Room; many-to-many with Course; owner ID is used for authorization checks |
| `Course` | Course code and course name used to organize and search sessions | Many-to-many with Booking; course deletion removes its join rows while preserving bookings |
| `ApplicationUser` and Identity tables | Registered student account, password hash, lockout and cookie identity data | A booking stores the owning user ID for authorization checks |
| `BookingCourse` | Join table for the Booking–Course many-to-many relationship | Composite key `(BookingId, CourseId)` |

The database seeds four rooms and three example courses through the initial migration. Seed values are examples and can be edited or removed in the application. Migrations are used instead of `EnsureCreated` so later model changes can be applied to an existing database.

### 4.2 Data access and lifecycle

Database access is asynchronous through Entity Framework Core. Read operations use async query methods and writes use `SaveChangesAsync`, so request threads are not synchronously held while waiting for I/O. `Program.cs` applies pending migrations at application startup. The connection string is `Data Source=studyrooms-v2.db`; the file is created in the working directory used to launch the project. The migration source is in `Migrations/`.

To create a clean local dataset, stop the application and remove `studyrooms-v2.db` from the project working directory. On next startup, EF Core recreates it and applies the migrations. Keep the database file out of Git; `.gitignore` excludes `*.db` and SQLite journal files.

### 4.3 Implementation and coding style

Files are grouped by what they do: controllers handle requests, ViewModels hold form data, services apply booking rules, and repositories access the database. Async methods are used for database calls. The booking rules are separate so they can be tested without a database. Forms use data annotations and server-side checks.

## 5. Feature breakdown and traceability

### 5.1 Find a free room

The home page accepts a time range and optional floor and projector filters. The repository returns rooms with no overlapping booking in that time window. A results table shows each room's floor, capacity, and projector availability, with a button to start a booking.

### 5.2 Create and manage bookings

Signed-in students can create bookings with a room, time range, subject, optional description, and zero or more courses. A booking is associated with the signed-in account; the student number comes from the account rather than being trusted from the form. The booking list can be filtered by subject, course, start time, and end time. Owners can edit or delete their own bookings.

### 5.3 Manage rooms and courses

Signed-in users can create, view, edit, and delete rooms and courses. Room and course forms validate their values on the server and display client-side validation when the CDN scripts load. Duplicate course codes are rejected by the unique database index and surfaced as a form error.

### 5.4 Domain rules

- The end time must be later than the start time.
- A study session cannot exceed four hours.
- A new booking cannot begin in the past (a five-minute tolerance handles small clock differences between form submission and server validation).
- Two bookings for the same room conflict when `startA < endB && endA > startB`. Back-to-back bookings are allowed.
- Booking edits exclude the booking being edited from the conflict query.

The rule functions are in `Domain/BookingRules.cs`; repository queries apply the same interval condition when checking availability.

### 5.5 User experience and conditional rendering

The workflow follows the expected order: search for a room, choose a time, then create and manage a study session. Shared navigation links lead to room search, bookings, rooms, and courses. Forms group room/time/session details, show validation beside the relevant fields, and explain when a result list is empty. The booking form updates room details when the selected room changes. The interface uses standard Bootstrap components and familiar labels with no custom visual theme. Section 8 records the interface choices.

The views use `if`/`else` blocks to show results or an empty message, ternary expressions for values such as projector availability, and `&&` to show room results only after a valid search. Examples are in `Views/Bookings/Index.cshtml`, `Views/Rooms/Index.cshtml`, and `Views/Home/Index.cshtml`.

## 6. Security, resilience, and testing

### 6.1 Authentication and authorization

Students register with display name, student number, email address, and a password. Passwords must contain at least 10 characters, upper- and lower-case letters, a number, and a symbol. Identity stores password hashes, requires unique email addresses, and locks an account after five failed login attempts for ten minutes. Every modifying form uses anti-forgery validation.

Bookings, rooms, and courses require authentication. A student can edit or delete only bookings whose stored owner ID matches the signed-in account. All authenticated users may manage the shared room and course catalogs; role-based access is not implemented because the assignment does not require roles.

Email confirmation and password reset email are not configured. Accounts are self-registered for this course project. Do not use a real password that you also use for another service.

### 6.2 Resilience and error handling

The application uses a friendly global exception page and status-code page. Controllers check model state before saving, catch expected EF Core update failures, log server details through `ILogger`, and return user-facing messages that avoid exposing database exception details. Booking conflicts are logged and shown as a form-level validation message. Data annotations drive both browser-side feedback (when the validation scripts load) and authoritative server-side validation; booking time conflicts and duration limits are checked again in the service. Client-side checks improve convenience but can be bypassed, so they are not treated as a security boundary.

Logging covers the request and persistence paths: `AccountController` records registration and sign-in outcomes; `HomeController` records room searches; the booking, room, and course services log successful writes, while `BookingService` also logs invalid-window and room-conflict rejections. Their controllers log caught database-write failures with the exception and relevant entity context. Validation failures are returned on the form without throwing, and unexpected exceptions from any controller or service reach the framework-logged exception middleware configured in `Program.cs`. Services do not swallow persistence exceptions, so the controller can both log the failure and return a safe message.

The availability query and save are separate operations. Two requests arriving at nearly the same time could both observe availability before either saves. A production deployment should add a transaction or database-level concurrency strategy and operational backup/monitoring.

### 6.3 Unit tests and verification

`BookingRulesTests.cs` now has 12 cases: six valid booking scenarios and six scenarios the rules should reject. They cover booking length, room conflicts, and start times. This shortened test set has not been run yet.

Run the checks from the repository root:

```bash
dotnet build
dotnet test tests/StudyRoomBooking.Tests/StudyRoomBooking.Tests.csproj
```

The latest app build completed with no errors. NuGet showed a `NU1900` warning because it could not reach the vulnerability-data feed. A manual check covered registration, sign-in, creating a booking, searching by subject and course, and rejecting a room-time conflict. The edit flow still needs another browser check after its EF Core tracking fix.

### 6.4 Running the application and examiner access

Prerequisite: install the .NET 10 SDK. Node.js is not required. From the repository root:

```bash
dotnet run
```

Open the URL printed in the terminal; the configured HTTP address is `http://localhost:5080`. Select **Create account** to register a student account, then sign in to create bookings and manage the catalogs. The application is local: an examiner on another computer cannot open your `localhost` URL.

No shared credentials are required: an examiner can select **Create account** and register their own account. The GitHub repository is currently private. Before submission, invite each examiner by their GitHub username from repository **Settings → Collaborators → Add people**, or change repository visibility only if course policy permits. If the assignment expects an online hosted application, deploy it and add the public URL here; no public URL exists yet.

## 7. AI usage and verification

Claude helped with the first project draft. Codex later helped update Identity and courses, change service/repository code, fix a booking edit issue, write tests, simplify the interface, and edit this report. Follow the course's AI-use rules for the final submission, and make sure you understand and can explain the submitted code. Build and test results are in Section 6.3.

### 7.3 Course materials and references

The project uses the teacher's MVC, EF Core/DAL, validation, security, logging, and testing materials. The main references were the MVC overview and Shop MVC demos, `3-EntityFramework.pdf`, the Shop Database demos, `8-LoggingErrorHandlingInputValidation.pdf`, `9-SecurityTesting.pdf`, `Demo-ShopErrorHandlingLogging.pdf`, and `Demo-ShopInputValidation.pdf`. The related course example repositories are [ITPE3200-25H](https://github.com/Baifan-Zhou/ITPE3200-25H) and [ITPE3200-26H](https://github.com/Baifan-Zhou/ITPE3200-26H). The study-room app has its own code and database model.

## 8. User experience and usability

The interface uses Bootstrap's basic navigation, forms, buttons, and tables with a white background. There is no custom stylesheet, decorative graphics, or icon library. The home page has one room search form. Users can reach room search, bookings, rooms, and courses through the main navigation. Empty result messages explain what happened and suggest a next action. Success and error messages appear after changes. Booking forms show room details, preserve validation feedback, and offer a cancel link.

Form fields have visible labels, validation messages are associated with their inputs, and Bootstrap breakpoints adapt the pages to smaller screens. Bootstrap and client-side validation scripts are loaded from public CDNs, so client-side enhancements require an internet connection; server-side validation remains authoritative when client scripts are unavailable.

## 9. Conclusion and self-reflection

The app can search for rooms, create and manage bookings, and manage rooms and courses. Its main rules prevent overlapping room bookings and sessions longer than four hours.

Before submission, the edit flow still needs a browser check, and examiners need access to the private repository or a hosted URL. The room conflict check does not prevent two requests arriving at the same time from both booking the same slot. Joining sessions and leaving messages are not implemented.
