using StudyRoomBooking.Domain;
using Xunit;

namespace StudyRoomBooking.Tests;

public sealed class BookingRulesTests
{
    private static readonly DateTime Day = new(2026, 10, 26, 10, 0, 0);

    [Fact]
    public void ValidWindow_AllowsShortSession() =>
        Assert.True(BookingRules.HasValidWindow(Day, Day.AddMinutes(30)));

    [Fact]
    public void ValidWindow_AllowsExactlyFourHours() =>
        Assert.True(BookingRules.HasValidWindow(Day, Day.AddHours(4)));

    [Fact]
    public void ValidWindow_RejectsMoreThanFourHours() =>
        Assert.False(BookingRules.HasValidWindow(Day, Day.AddHours(4).AddMinutes(1)));

    [Fact]
    public void ValidWindow_RejectsZeroDuration() =>
        Assert.False(BookingRules.HasValidWindow(Day, Day));

    [Fact]
    public void ValidWindow_RejectsEndBeforeStart() =>
        Assert.False(BookingRules.HasValidWindow(Day, Day.AddMinutes(-1)));

    [Fact]
    public void Overlap_DetectsPartialOverlapAtTheEnd() =>
        Assert.True(BookingRules.Overlaps(Day, Day.AddHours(2), Day.AddHours(1), Day.AddHours(3)));

    [Fact]
    public void Overlap_DetectsIdenticalWindows() =>
        Assert.True(BookingRules.Overlaps(Day, Day.AddHours(1), Day, Day.AddHours(1)));

    [Fact]
    public void Overlap_AllowsBackToBackSessions() =>
        Assert.False(BookingRules.Overlaps(Day, Day.AddHours(1), Day.AddHours(1), Day.AddHours(2)));

    [Fact]
    public void Overlap_AllowsGapBetweenSessions() =>
        Assert.False(BookingRules.Overlaps(Day, Day.AddHours(1), Day.AddHours(2), Day.AddHours(3)));

    [Fact]
    public void StartsNearOrAfterNow_AllowsFutureStart() =>
        Assert.True(BookingRules.StartsNearOrAfterNow(Day.AddMinutes(1), Day));

    [Fact]
    public void StartsNearOrAfterNow_AllowsFiveMinuteClockTolerance() =>
        Assert.True(BookingRules.StartsNearOrAfterNow(Day.AddMinutes(-5), Day));

    [Fact]
    public void StartsNearOrAfterNow_RejectsStartBeyondTolerance() =>
        Assert.False(BookingRules.StartsNearOrAfterNow(Day.AddMinutes(-6), Day));
}
